#!/bin/sh
npm install
node server.js
